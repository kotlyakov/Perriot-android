from pathlib import Path
import re
s=Path('/workspace/pierrot-collection-refined.html').read_text()
old="const satellite=element('span','category-satellite');satellite.setAttribute('aria-hidden','true');item.append(satellite);"
new="const face=element('span','planet-button-face');face.setAttribute('aria-hidden','true');const satellite=element('span','category-satellite');satellite.setAttribute('aria-hidden','true');for(const cls of ['sat-panel sat-panel-left','sat-panel sat-panel-right','sat-body','sat-dish','sat-antenna'])satellite.append(element('span',cls));item.append(face,satellite);startSatelliteOrbit(item,satellite);"
assert old in s;s=s.replace(old,new)
start=s.index('function sealDrawing(){')
orbit='''function satellitePosition(phase,width,height){
 const a=width*.54,b=height*.28,tilt=-16*Math.PI/180,x=a*Math.cos(phase),y=b*Math.sin(phase);
 return {x:x*Math.cos(tilt)-y*Math.sin(tilt),y:x*Math.sin(tilt)+y*Math.cos(tilt),front:Math.sin(phase)>=0,scale:.82+.16*Math.sin(phase)};
}
function startSatelliteOrbit(button,satellite){
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;let started;
 function frame(now){if(!button.isConnected)return;started??=now;const phase=reduced?.6:(now-started)/6200*Math.PI*2+.6;
 const p=satellitePosition(phase,button.clientWidth,button.clientHeight);
 satellite.style.transform=`translate(-50%,-50%) translate(${p.x}px,${p.y}px) rotate(-23deg) scale(${p.scale})`;
 satellite.style.zIndex=p.front?'4':'0';satellite.style.filter=`brightness(${p.front?1.12:.72}) drop-shadow(0 2px 2px #10262699)`;
 if(!reduced)requestAnimationFrame(frame);
 }requestAnimationFrame(frame);
}
'''
s=s[:start]+orbit+s[start:]
css='''
/* Review v3: a miniature spacecraft in a tilted orbital plane. */
#pierrot-native-review #collection_category_Planet{isolation:isolate}
#pierrot-native-review #collection_category_Planet>.planet-button-face{position:absolute;inset:0;border-radius:inherit;background:#3b7e97;z-index:1;pointer-events:none}
#pierrot-native-review #collection_category_Planet>strong,#pierrot-native-review #collection_category_Planet>.collection-category-count{position:relative;z-index:2}
#pierrot-native-review .category-satellite{left:50%;top:50%;width:34px;height:25px;border-radius:0;background:none;box-shadow:none;offset-path:none;animation:none!important;transform-origin:center;pointer-events:none}
#pierrot-native-review .category-satellite>span{position:absolute;display:block;box-sizing:border-box}
#pierrot-native-review .sat-panel{top:8px;width:11px;height:13px;border:1px solid #b1c6ca;background:repeating-linear-gradient(0deg,transparent 0 3px,#b7dfdf88 3px 4px),repeating-linear-gradient(90deg,#174f7b 0 3px,#8ac2d3 3px 4px);box-shadow:0 1px 1px #102626}
#pierrot-native-review .sat-panel-left{left:0;transform:skewY(-9deg)}
#pierrot-native-review .sat-panel-right{right:0;transform:skewY(9deg)}
#pierrot-native-review .sat-body{left:12px;top:6px;width:10px;height:17px;background:linear-gradient(90deg,#9b762b,#f5df9a 45%,#c5a257 65%,#866331);border:1px solid #e7d8ac;border-radius:2px;box-shadow:0 1px 2px #102626}
#pierrot-native-review .sat-dish{left:13px;top:2px;width:10px;height:7px;border:1px solid #c9d5d3;border-radius:2px 2px 70% 70%;background:linear-gradient(#f3f0da,#829b9e);transform:rotate(-30deg)}
#pierrot-native-review .sat-antenna{left:18px;top:0;width:1px;height:7px;background:#f3e8c8;transform:rotate(-30deg);transform-origin:bottom}
/* Flowing interference colours rather than a muted static rainbow. */
#pierrot-native-review #collection_category_Spectral{background:linear-gradient(120deg,#284f8b 0%,#5054bd 15%,#a23ca3 30%,#d66a90 43%,#d8ad68 53%,#3bab9e 68%,#3479bc 83%,#7c49ad 100%)!important;background-size:400% 300%!important;animation:prism-current 4s linear infinite!important;position:relative;overflow:hidden;text-shadow:0 2px 3px #172e38}
#pierrot-native-review #collection_category_Spectral::after{content:'';position:absolute;inset:-70%;pointer-events:none;background:linear-gradient(115deg,transparent 35%,#e1ffff18 44%,#fff9e373 49%,#b8e9ff22 54%,transparent 63%);animation:prism-light 3.2s linear infinite;mix-blend-mode:screen}
#pierrot-native-review #collection_category_Spectral>strong,#pierrot-native-review #collection_category_Spectral>.collection-category-count{position:relative;z-index:2}
#pierrot-native-review .collection-card[data-card-set=Spectral][data-discovered=true]{background:linear-gradient(130deg,#769bce,#a58bd7,#d78ebd,#dbb477,#7ac6aa,#6eafd5,#a58bd7)!important;background-size:400% 300%!important;animation:prism-current 4s linear infinite!important;border-color:#afcfe0}
#pierrot-native-review .collection-card[data-card-set=Spectral][data-discovered=true]::after{content:'';position:absolute;inset:0;pointer-events:none;z-index:2;background:linear-gradient(115deg,transparent 25%,#e3ffff00 38%,#f1fffca0 49%,#afe8ff25 57%,transparent 70%);background-size:300% 100%;animation:prism-card-light 3s linear infinite;mix-blend-mode:screen}
#pierrot-native-review .collection-card[data-card-set=Spectral][data-discovered=true]>.shop-art{color:#302b5b!important;animation:none;z-index:1}
@keyframes prism-current{0%{background-position:0% 0%}25%{background-position:100% 30%}50%{background-position:100% 100%}75%{background-position:0% 70%}100%{background-position:0% 0%}}
@keyframes prism-light{from{transform:translateX(-32%) rotate(-8deg)}to{transform:translateX(32%) rotate(-8deg)}}
@keyframes prism-card-light{from{background-position:150% 50%}to{background-position:-50% 50%}}
@media(prefers-reduced-motion:reduce){#pierrot-native-review #collection_category_Spectral,#pierrot-native-review #collection_category_Spectral::after,#pierrot-native-review .collection-card[data-card-set=Spectral],#pierrot-native-review .collection-card[data-card-set=Spectral]::after{animation:none!important}}
'''
s=s.replace('</style>',css+'</style>',1)
s=s.replace("collection();root.querySelector('#collection_category_Joker').click();root.querySelector('#review-status').remove();", "collection();root.querySelector('#review-status').remove();")
Path('/workspace/pierrot-collection-prism.html').write_text(s)
Path('preview-v3-script.js').write_text(re.search(r'<script>(.*?)</script>',s,re.S)[1])
print('Updated preview:',len(s.encode()),'bytes')
