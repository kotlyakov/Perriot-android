from pathlib import Path
import re

s=Path('/workspace/pierrot-collection-pages-review.html').read_text()
# Reuse the project's existing collection renderer, art, fonts, and navigation.
s=s.replace("const profile=data.profile;", """const profile=data.profile;
const categoryCounts={};for(const entry of data.entries){const i=categoryCounts[entry.set]??0;categoryCounts[entry.set]=i+1;entry.discovered=i%3===0||i%7===3;entry.unlocked=entry.discovered;entry.sticker=null;}
""")
a=s.index('   function details(entry,card)')
b=s.index('\n   for(const capacity',a)
s=s[:a]+'''   function details(entry,card){
    if(card.dataset.animating==='true')return;
    const known=entry.discovered,display=known?localized(entry):null;
    tooltip.replaceChildren(element('strong','',known?display.name:'Ещё не открыто'));
    if(known&&set==='Joker'){const rarity=catalog.centres.find(c=>c.key===entry.id)?.rarity,badge=element('span','collection-rarity',({1:'Обычный',2:'Необычный',3:'Редкий',4:'Легендарный'})[rarity]??'Джокер');badge.dataset.rarity=String(rarity);tooltip.append(badge);}
    tooltip.append(element('p','',known?display.description:'Откройте эту карту в игре, чтобы увидеть её описание.'));
    showCardTooltip(tooltip,card,{container:root});
   }
''' + s[b:]
a=s.index('if(entry.discovered&&entry.unlocked){card.append(artwork',s.index('function renderCollectionView'))
b=s.index('\n    if(entry.discovered&&entry.sticker)',a)
s=s[:a]+'''card.append(artwork({entityId:entry.id},entry.set==='Booster'?'booster':'collection'));
    if(!entry.discovered){card.classList.add('sealed-card');card.setAttribute('aria-label','Ещё не открыто');
     const seal=element('span','card-seal');seal.setAttribute('aria-hidden','true');seal.innerHTML=sealDrawing();card.append(seal);
    }
''' + s[b:]
# UI preview only: keep cards large on a phone instead of scaling a whole landscape screen.
navStart=s.index('<nav class="review-nav"')
navEnd=s.index('</nav>',navStart)+6
s=s[:navStart]+'''<nav class="review-nav" aria-label="Просмотр коллекции"><button data-review="categories">Разделы коллекции</button><button data-review="aftergame" class="demo-unlock">После игры: новая карта</button></nav>'''+s[navEnd:]
newcss='''
#pierrot-native-review .review-stage{aspect-ratio:auto!important;background:transparent;overflow:visible;height:auto!important}
#pierrot-native-review #stage{display:none}
#pierrot-native-review dialog.menu-dialog{position:relative!important;inset:auto!important;left:auto!important;top:auto!important;transform:none!important;margin:0 auto!important;width:100%!important;max-width:760px;padding:14px!important;gap:12px!important;border:5px solid #899c98!important;background:#183332;box-shadow:0 6px #102626;border-radius:18px}
#pierrot-native-review #dialog-title{font-size:24px;margin:0;text-align:center}
#pierrot-native-review #dialog-body{height:510px!important;min-height:0;padding:10px!important}
#pierrot-native-review #dialog-actions button{min-height:44px;width:100%;font-size:20px;background:#f59b05;color:#f0e5c8}
#pierrot-native-review .review-nav{justify-content:center;max-width:760px;margin:0 auto 12px;gap:10px}
#pierrot-native-review .review-nav button{font-weight:500;font-size:15px;padding:12px 16px;touch-action:manipulation}
#pierrot-native-review .review-nav .demo-unlock{background:#bf4e43}
#pierrot-native-review .collection-view .collection-grid{padding:12px;gap:18px}
#pierrot-native-review .collection-card-row{gap:14px}
#pierrot-native-review .collection-card{max-width:112px!important}
#pierrot-native-review .sealed-card{background:#b3b5b0!important;border-color:#8a918d!important;color:#5e6663!important}
#pierrot-native-review .sealed-card>.shop-art{filter:grayscale(1) brightness(.67);opacity:.7}
#pierrot-native-review .card-seal{position:absolute;inset:-5px;pointer-events:none;z-index:3;display:block}
#pierrot-native-review .card-seal svg{display:block;width:100%;height:100%;overflow:visible}
#pierrot-native-review .chain-left,#pierrot-native-review .chain-right,#pierrot-native-review .lock-group{transform-box:fill-box;transform-origin:center}
#pierrot-native-review .collection-card[data-animating=true]{overflow:visible!important;z-index:10;pointer-events:none}
#pierrot-native-review .collection-tooltip{z-index:25}
#pierrot-native-review .after-game{position:absolute;inset:0;z-index:120;border-radius:12px;background:#102626f5;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:20px;text-align:center;padding:24px;color:#f0e5c8}
#pierrot-native-review .after-game strong{font-size:26px;font-weight:500}
#pierrot-native-review .after-game button{background:#f59b05;padding:14px 24px;font-size:22px}
#pierrot-native-review .collection-card:focus-visible{outline:3px solid #f59b05}
@media(max-width:480px){#pierrot-native-review dialog.menu-dialog{padding:8px!important;border-width:4px!important}#pierrot-native-review #dialog-body{height:370px!important;padding:4px!important}#pierrot-native-review .collection-view{padding:3px;gap:8px}#pierrot-native-review .collection-view .collection-grid{padding:8px;gap:16px}#pierrot-native-review .collection-card-row{gap:7px}#pierrot-native-review .collection-card{flex-basis:calc((100% - (var(--collection-columns) - 1)*7px)/var(--collection-columns))!important;min-height:0!important}#pierrot-native-review .collection-category-column{gap:7px}#pierrot-native-review .collection-categories{gap:10px}#pierrot-native-review .collection-categories button{font-size:16px}#pierrot-native-review .collection-consumables{padding:6px;gap:4px}#pierrot-native-review .collection-tooltip{font-size:15px;width:240px}#pierrot-native-review .collection-tooltip>strong{font-size:17px}#pierrot-native-review .collection-grid[data-set=Back] .collection-card{flex-basis:36%!important;min-height:150px!important}#pierrot-native-review .collection-deck-description{padding:8px;font-size:14px}#pierrot-native-review .collection-deck-description p{font-size:14px!important}}
'''
s=s.replace('</style>',newcss+'</style>',1)
insert='''
function sealDrawing(){
 const links=(reverse)=>Array.from({length:12},(_,i)=>{const x=-9+i*8,y=reverse?90-i*6.4:10+i*6.4;return `<ellipse cx="${x}" cy="${y}" rx="6.1" ry="3.7" transform="rotate(${reverse?-40:40} ${x} ${y})" fill="#555f60" stroke="#172426" stroke-width="2.8"/><ellipse cx="${x}" cy="${y}" rx="6.1" ry="3.7" transform="rotate(${reverse?-40:40} ${x} ${y})" fill="none" stroke="#b6beb9" stroke-width="1.4"/>`;}).join('');
 return `<svg viewBox="0 0 72 100" preserveAspectRatio="none"><g class="chain-left">${links(false)}</g><g class="chain-right">${links(true)}</g><g class="lock-group"><path class="lock-shackle" d="M26 47V35C26 21 46 21 46 35V47" fill="none" stroke="#18292a" stroke-width="9"/><path class="lock-shackle lock-highlight" d="M26 47V35C26 21 46 21 46 35V47" fill="none" stroke="#d4d5c6" stroke-width="5"/><rect x="19" y="44" width="34" height="28" rx="4" fill="#747f79" stroke="#192d2c" stroke-width="2"/><path d="M22 48H50" stroke="#c8cbba" stroke-width="2"/><circle cx="36" cy="55" r="4" fill="#1a2c2b"/><path d="M36 56V64" stroke="#1a2c2b" stroke-width="3"/></g></svg>`;
}
let revealing=false;
async function revealCard(card,entry){
 revealing=true;card.dataset.animating='true';dismissCardTooltip();
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const play=(node,frames,options)=>node.animate(frames,{fill:'forwards',...options}).finished.catch(()=>{});
 try{if(!reduced){
  await play(card,[{transform:'translateX(0)'},{transform:'translateX(-3px) rotate(-2deg)'},{transform:'translateX(3px) rotate(2deg)'},{transform:'translateX(0)'}],{duration:220});
  await Promise.all([...card.querySelectorAll('.lock-shackle')].map(n=>play(n,[{transform:'translateY(0) rotate(0deg)'},{transform:'translateY(-10px) rotate(-24deg)'}],{duration:260,easing:'ease-out'})));
  await Promise.all([
   play(card.querySelector('.chain-left'),[{transform:'translate(0,0) rotate(0deg)',opacity:1},{transform:'translate(-48px,90px) rotate(-42deg)',opacity:0}],{duration:650,easing:'cubic-bezier(.5,0,.9,.4)'}),
   play(card.querySelector('.chain-right'),[{transform:'translate(0,0) rotate(0deg)',opacity:1},{transform:'translate(48px,90px) rotate(42deg)',opacity:0}],{duration:650,easing:'cubic-bezier(.5,0,.9,.4)'}),
   play(card.querySelector('.lock-group'),[{transform:'translateY(0) rotate(0deg)',opacity:1},{transform:'translateY(105px) rotate(24deg)',opacity:0}],{duration:600,easing:'ease-in'}),
   play(card.querySelector('.shop-art'),[{filter:'grayscale(1) brightness(.67)',opacity:.7},{filter:'grayscale(0) brightness(1)',opacity:1}],{duration:950,easing:'ease-out'}),
   play(card,[{boxShadow:'0 0 0 0 #f5c86a00'},{boxShadow:'0 0 26px 6px #f5c86a88',offset:.45},{boxShadow:'0 4px #071d21'}],{duration:1000})
  ]);
 }
 entry.discovered=true;entry.unlocked=true;card.classList.remove('sealed-card');card.querySelector('.card-seal').remove();card.dataset.discovered='true';card.dataset.unlocked='true';card.dataset.cardState='discovered';card.setAttribute('aria-label',data.descriptions[entry.id]?.name??entry.name??'Открытая карта');
 }finally{card.dataset.animating='false';revealing=false;root.querySelector('[data-review=aftergame]').disabled=false;}
}
function afterGame(){
 if(revealing||root.querySelector('.after-game'))return;
 if(!root.querySelector('.collection-grid')){collection();root.querySelector('#collection_category_Joker').click();}
 const card=[...root.querySelectorAll('.sealed-card')][0];if(!card)return;
 const entry=data.entries.find(e=>e.id===card.dataset.entryId);dismissCardTooltip();
 const panel=document.createElement('div');panel.className='after-game';
 const title=document.createElement('strong');title.textContent='Партия завершена';
 const subtitle=document.createElement('span');subtitle.textContent='Открыта новая карта коллекции';
 const back=document.createElement('button');back.textContent='В коллекцию';back.onclick=()=>{panel.remove();root.querySelector('[data-review=aftergame]').disabled=true;revealCard(card,entry);};panel.append(title,subtitle,back);root.querySelector('.review-stage').append(panel);back.focus();
}
'''
s=s.replace('const actions={options,',insert+"const actions={categories:collection,aftergame:afterGame,options,")
a=s.index("const box=root.querySelector('.review-stage');")
s=s[:a]+"collection();root.querySelector('#collection_category_Joker').click();root.querySelector('#review-status').remove();})();\n</script>\n</div>\n"
out=Path('/workspace/pierrot-collection-unlock.html');out.write_text(s)
print(out, len(s.encode()))
