from pathlib import Path
import re
s=Path('/workspace/pierrot-collection-unlock.html').read_text()
s=s.replace("active.tip.hidden=true;active.tip.remove?.();active.card.removeAttribute?.('aria-describedby');active=null;", "active.tip.hidden=true;active.tip.remove?.();active.card.removeAttribute?.('aria-describedby');active.card.classList.remove('card-inspected');active=null;")
s=s.replace("active={tip,card};card.setAttribute", "active={tip,card};card.classList.add('card-inspected');card.setAttribute")
s=s.replace("const cycle=(next,direction=Math.sign(next-page))=>{if(animation||pages===1)return;page=(next+pages)%pages;draw(direction);};", """const cycle=async(next,direction=Math.sign(next-page))=>{
    if(animation||pages===1||revealing)return;dismissCardTooltip();
    if(!matchMedia('(prefers-reduced-motion: reduce)').matches){
     const outgoing=grid.animate([{transform:'translateX(0) rotateY(0deg)',opacity:1},{transform:`translateX(${-direction*22}px) rotateY(${-direction*9}deg)`,opacity:0}],{duration:150,easing:'ease-in',fill:'forwards'});animation=outgoing;
     try{await outgoing.finished;}catch{return;}if(!grid.isConnected)return;
    }
    page=(next+pages)%pages;draw(direction);
   };""")
s=s.replace("const motion=surface.animate([{transform:`translateX(${direction*24}px)`,opacity:.35},{transform:'translateX(0)',opacity:1}],{duration:180,easing:'ease-out'});", """const motion=surface.animate([{transform:`perspective(900px) translateX(${direction*35}px) rotateY(${direction*10}deg) scale(.975)`,opacity:.15},{transform:`perspective(900px) translateX(${-direction*3}px) rotateY(${-direction*1}deg) scale(1.008)`,opacity:1,offset:.78},{transform:'perspective(900px) translateX(0) rotateY(0deg) scale(1)',opacity:1}],{duration:300,easing:'cubic-bezier(.2,.7,.25,1)'});
    [...grid.querySelectorAll('.collection-card-row')].forEach((row,i)=>row.animate([{transform:`translateX(${direction*12}px) rotate(${direction*.8}deg)`},{transform:'translateX(0) rotate(0deg)'}],{duration:290,delay:i*22,easing:'ease-out',fill:'backwards'}));""")
a=s.index('function sealDrawing(){');b=s.index('let revealing=false;',a)
s=s[:a]+'''function sealDrawing(){
 const links=reverse=>Array.from({length:12},(_,i)=>{const x=-9+i*8,y=reverse?90-i*6.4:10+i*6.4;return `<g class="chain-link" data-x="${x}" data-y="${y}" data-angle="${reverse?-40:40}" transform="translate(${x} ${y}) rotate(${reverse?-40:40})"><ellipse rx="6.1" ry="3.7" fill="#555f60" stroke="#172426" stroke-width="2.8"/><ellipse rx="6.1" ry="3.7" fill="none" stroke="#b6beb9" stroke-width="1.4"/></g>`;}).join('');
 return `<svg viewBox="0 0 72 100" preserveAspectRatio="none"><g class="chain-left">${links(false)}</g><g class="chain-right">${links(true)}</g><g class="lock-group"><g class="lock-shackle hinge"><path d="M26 46V35C26 21 46 21 46 35V47" fill="none" stroke="#18292a" stroke-width="9"/><path d="M26 46V35C26 21 46 21 46 35V47" fill="none" stroke="#d4d5c6" stroke-width="5"/></g><rect x="19" y="44" width="34" height="28" rx="4" fill="#747f79" stroke="#192d2c" stroke-width="2"/><path d="M22 48H50" stroke="#c8cbba" stroke-width="2"/><circle cx="36" cy="55" r="4" fill="#1a2c2b"/><path d="M36 56V64" stroke="#1a2c2b" stroke-width="3"/></g></svg>`;
}
function releaseChains(card){
 const chains=[...card.querySelectorAll('.chain-left,.chain-right')];
 return new Promise(resolve=>{let start;function frame(now){
  start??=now;const t=Math.min(1,(now-start)/850);
  chains.forEach((chain,side)=>{const sign=side?1:-1;
   const points=[...chain.children].map((link,i)=>{const u=i/11,p=Math.max(0,Math.min(1,(t-u*.12)/.88));return {link,x:Number(link.dataset.x)+sign*36*p*p+12*Math.sin(Math.PI*u)*Math.sin(Math.PI*p),y:Number(link.dataset.y)+110*p*p+34*Math.sin(Math.PI*u)*Math.sin(Math.PI*p)};});
   points.forEach((point,i)=>{const before=points[Math.max(0,i-1)],after=points[Math.min(11,i+1)],angle=Math.atan2(after.y-before.y,after.x-before.x)*180/Math.PI;point.link.setAttribute('transform',`translate(${point.x} ${point.y}) rotate(${angle})`);});
   chain.style.opacity=String(Math.max(0,1-Math.pow(t,3)));
  });
  if(t<1&&card.isConnected)requestAnimationFrame(frame);else resolve();
 }requestAnimationFrame(frame);});
}
''' +s[b:]
s=s.replace("{transform:'translateY(0) rotate(0deg)'},{transform:'translateY(-10px) rotate(-24deg)'}", "{transform:'rotate(0deg)'},{transform:'rotate(34deg)'}")
s=s.replace("{duration:260,easing:'ease-out'}", "{duration:380,easing:'cubic-bezier(.2,.8,.3,1)'}")
a=s.index("   play(card.querySelector('.chain-left')");b=s.index("   play(card.querySelector('.lock-group')",a)
s=s[:a]+"   releaseChains(card),\n"+s[b:]
s=s.replace("{duration:600,easing:'ease-in'}", "{duration:850,delay:90,easing:'ease-in'}")
s=s.replace("item.append(element('strong','',setNames[category]));", "item.append(element('strong','',setNames[category]));if(category==='Planet'){const satellite=element('span','category-satellite');satellite.setAttribute('aria-hidden','true');item.append(satellite);}")
css='''
/* Collection review v2: inspection, materials, fit and motion. */
#pierrot-native-review{--tarot-color:#bc793d;--planet-color:#5cabc6;--spectral-color:#8e82bb}
#pierrot-native-review .collection-card.card-inspected{outline:3px solid #f5b541!important;outline-offset:3px;box-shadow:0 0 15px #f5b54166!important;z-index:12}
#pierrot-native-review .lock-shackle.hinge{transform-box:view-box;transform-origin:46px 47px}
#pierrot-native-review .collection-view .collection-card-row{align-items:center;min-height:0;gap:12px}
#pierrot-native-review .collection-view .collection-card-row .collection-card{height:auto!important;align-self:center;min-width:0;max-width:112px!important;width:calc((100% - (var(--collection-columns) - 1)*12px)/var(--collection-columns))!important;flex:0 1 calc((100% - (var(--collection-columns) - 1)*12px)/var(--collection-columns))!important;aspect-ratio:71/95}
#pierrot-native-review .collection-grid[data-set=Tag] .collection-card,#pierrot-native-review .collection-grid[data-set=Blind] .collection-card{max-width:58px!important;aspect-ratio:1!important;border-radius:50%}
#pierrot-native-review .collection-grid[data-set=Tag],#pierrot-native-review .collection-grid[data-set=Blind]{gap:10px!important}
#pierrot-native-review .collection-categories button{min-width:0;overflow-wrap:normal;word-break:normal;padding:10px 8px;line-height:1.2;position:relative;isolation:isolate}
#pierrot-native-review .collection-categories button strong{font-weight:500;max-width:100%}
#pierrot-native-review #collection_category_Tag{font-size:18px}
#pierrot-native-review .collection-consumables{flex:3.6;min-height:210px}
#pierrot-native-review .collection-consumables>div{gap:10px}
#pierrot-native-review #collection_category_Spectral{font-size:17px;min-height:64px}
#pierrot-native-review #collection_category_Tarot{background:#a76535!important;box-shadow:0 4px #603b23}
#pierrot-native-review #collection_category_Planet{background:#3b7e97!important;box-shadow:0 4px #214b60;overflow:visible}
#pierrot-native-review #collection_category_Spectral{background:linear-gradient(115deg,#986a68,#a18b53,#548d79,#427f96,#78659b,#986a68)!important;background-size:300% 300%!important;animation:spectral-flow 7s ease-in-out infinite}
#pierrot-native-review .collection-card[data-card-set=Tarot][data-discovered=true]{background:#efcf9f;border-color:#c68a4b}
#pierrot-native-review .collection-card[data-card-set=Planet][data-discovered=true]{background:#c7e2df;border-color:#71b7cb}
#pierrot-native-review .collection-card[data-card-set=Spectral][data-discovered=true]{background:linear-gradient(130deg,#e3bcba,#e4d4a1,#b6d4ba,#abcdd8,#ccb9dc,#e3bcba);background-size:300% 300%;animation:spectral-flow 7s ease-in-out infinite;border-color:#bcb0c7}
#pierrot-native-review .collection-card[data-card-set=Spectral][data-discovered=true]>.shop-art{animation:spectral-ink 7s linear infinite}
#pierrot-native-review .category-satellite{position:absolute;left:0;top:0;width:9px;height:9px;border-radius:50%;background:#ede4c8;box-shadow:0 0 7px #a8e2f6;offset-path:inset(2px round 14px);offset-distance:0%;animation:planet-orbit 6s linear infinite;pointer-events:none}
@keyframes planet-orbit{to{offset-distance:100%}}
@keyframes spectral-flow{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
@keyframes spectral-ink{0%,100%{color:#93606d}25%{color:#a17c34}50%{color:#398a84}75%{color:#7064a1}}
@media(max-width:480px){
 #pierrot-native-review #dialog-body{height:415px!important}
 #pierrot-native-review .collection-view .collection-card-row{gap:7px}
 #pierrot-native-review .collection-view .collection-card-row .collection-card{width:calc((100% - (var(--collection-columns) - 1)*7px)/var(--collection-columns))!important;flex-basis:calc((100% - (var(--collection-columns) - 1)*7px)/var(--collection-columns))!important}
 #pierrot-native-review .collection-grid[data-set=Tag] .collection-card,#pierrot-native-review .collection-grid[data-set=Blind] .collection-card{max-width:45px!important}
 #pierrot-native-review .collection-grid[data-set=Spectral]{gap:12px!important}
 #pierrot-native-review .collection-categories{grid-template-columns:1.12fr 1fr;gap:10px}
 #pierrot-native-review .collection-categories button{font-size:15px;padding:9px 5px;line-height:1.2}
 #pierrot-native-review #collection_category_Tag{font-size:15px;min-height:56px}
 #pierrot-native-review #collection_category_Spectral{font-size:14px;min-height:60px}
 #pierrot-native-review .collection-consumables{padding:6px 5px;gap:4px;min-height:210px}
 #pierrot-native-review .collection-group-title{font-size:13px}
 #pierrot-native-review .collection-category-count{font-size:12px}
}
@media(prefers-reduced-motion:reduce){#pierrot-native-review .category-satellite,#pierrot-native-review #collection_category_Spectral,#pierrot-native-review .collection-card[data-card-set=Spectral],#pierrot-native-review .collection-card[data-card-set=Spectral]>.shop-art{animation:none!important}}
'''
s=s.replace('</style>',css+'</style>',1)
Path('/workspace/pierrot-collection-refined.html').write_text(s)
Path('preview-v2-script.js').write_text(re.search(r'<script>(.*?)</script>',s,re.S)[1])
print('Created collection v2:',len(s.encode()),'bytes')
